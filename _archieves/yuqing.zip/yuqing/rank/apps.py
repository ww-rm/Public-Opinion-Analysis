from django.apps import AppConfig


class RankConfig(AppConfig):
    name = 'rank'
