# -*- coding: utf-8 -*-
import urllib.request
import json
import jsonpath


class Crawler():
    def __init__(self, globle_config):
        pass
